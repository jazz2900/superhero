def funny():
    print("halp")
    return 45
print(funny())